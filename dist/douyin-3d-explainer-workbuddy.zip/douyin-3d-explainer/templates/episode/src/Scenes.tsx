import React,{useLayoutEffect,useRef} from 'react';
import {clamp} from './config';
import {dropAt,ease} from './motion';
export function Icon({kind,color='currentColor'}:{kind:string;color?:string}){const paths:any={file:<><path d="M28 12h37l20 20v60H28z"/><path d="M65 12v22h20M40 48h32M40 62h32M40 76h22"/></>,tool:<path d="M65 15a23 23 0 0 0-28 28L13 67a13 13 0 0 0 19 19l25-25a23 23 0 0 0 28-29L68 49 53 34z"/>,lock:<><path d="M30 48V32a20 20 0 0 1 40 0v16"/><rect x="20" y="46" width="60" height="46" rx="10"/><path d="M50 62v15"/></>,check:<><rect x="14" y="14" width="72" height="72" rx="15"/><path d="m29 48 16 17 29-32"/></>};return <svg width="104" height="104" viewBox="0 0 100 100" fill="none" stroke={color} strokeWidth="5" strokeLinecap="round" strokeLinejoin="round">{paths[kind]||paths.file}</svg>}
function FallingTile({item,l,index}:{item:any;l:number;index:number}){const d=dropAt(l,item.dropAt??index*.3);return <div className="drop-slot" style={{zIndex:index+1}}><div className="drop-shadow" style={{opacity:d.visible?d.shadowOpacity:0,transform:`scale(${d.shadowScale})`,filter:`blur(${d.shadowBlur}px)`}}/><div className="small-tile" style={{'--mini':item.color,visibility:d.visible?'visible':'hidden',transform:`translateZ(${d.z}px) rotateZ(${d.rotation}deg) scale(${d.scaleX},${d.scaleY})`} as any}><Icon kind={item.icon} color={item.color}/><strong>{item.label}</strong></div></div>}
function SemanticCanvas({l,items}:{l:number;items:any[]}){
 const ref=useRef<HTMLCanvasElement>(null);
 useLayoutEffect(()=>{const ctx=ref.current!.getContext('2d')!;ctx.clearRect(0,0,1040,310);const points=[[130,155],[520,100],[910,155]];
  for(let i=0;i<2;i++){const [x,y]=points[i],[a,b]=points[i+1];ctx.strokeStyle=items[i].color+'cc';ctx.lineWidth=5.5;ctx.beginPath();ctx.moveTo(x,y);ctx.bezierCurveTo(x+135,y-110,a-135,b-110,a,b);ctx.stroke();
   // One document completes a transfer, then stops; no looping decorative dots.
   const local=l-.6-i*2.6;if(local<0||local>2.6)continue;const p=ease(local/2.6),q=1-p,px=q*q*q*x+3*q*q*p*(x+135)+3*q*p*p*(a-135)+p*p*p*a,py=q*q*q*y+3*q*q*p*(y-110)+3*q*p*p*(b-110)+p*p*p*b;
   ctx.save();ctx.translate(px,py);ctx.shadowColor='#243B5340';ctx.shadowBlur=9;ctx.shadowOffsetY=7;ctx.fillStyle='#FBFCFE';ctx.fillRect(-17,-23,34,46);ctx.shadowBlur=0;ctx.shadowOffsetY=0;ctx.strokeStyle=items[i].color;ctx.lineWidth=3;ctx.strokeRect(-17,-23,34,46);for(let j=0;j<3;j++){ctx.beginPath();ctx.moveTo(-10,-10+j*10);ctx.lineTo(10,-10+j*10);ctx.stroke()}ctx.restore();}
 },[l,items]);return <canvas ref={ref} width={1040} height={310} className="semantic-canvas"/>;
}
export function Scene({shot,l}:{shot:any;l:number}){
 const items=shot.items||[],isNetwork=shot.type==='network';
 // Extend this semantic router for each new episode; don't mechanically reuse the demo.
 return <div className={`semantic-world ${shot.type}`}>
 {isNetwork?<><SemanticCanvas l={l} items={items}/><div className="network-nodes">{items.map((it:any,i:number)=><div className="network-node" key={i} style={{left:80+i*390,top:i===1?44:100,opacity:ease((l-i*.35)/.45)}}><Icon kind={it.icon} color={it.color}/><strong>{it.label}</strong></div>)}</div></>:<div className="drop-row">{items.map((it:any,i:number)=><React.Fragment key={i}><FallingTile item={it} l={l} index={i}/>{i<items.length-1&&<svg className="flow-arrow" viewBox="0 0 100 60" style={{opacity:clamp((l-(it.dropAt??0)-.8)/.3)}}><path d="M5 30h75m-20-18 20 18-20 18" fill="none" stroke={it.color} strokeWidth="5" strokeLinecap="round" strokeLinejoin="round"/></svg>}</React.Fragment>)}</div>}
 <div className="takeaway" style={{opacity:ease((l-2.8)/.7)}}>{shot.takeaway}</div>
 </div>
}
